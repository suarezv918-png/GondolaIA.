# Góndola IA — MVP

Primera pantalla Android en Jetpack Compose, basada en el diseño aprobado.

## Estado
- Pantalla de inicio: lista
- Botón "Escanear góndola": preparado como punto de entrada
- Navegación visual: Inicio / Historial / Ajustes

## Próximo paso
Integrar CameraX para capturar la góndola y después conectar el análisis con IA.
