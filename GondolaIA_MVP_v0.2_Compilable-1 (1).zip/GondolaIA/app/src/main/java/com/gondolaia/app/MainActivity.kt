package com.gondolaia.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF06131C)
private val Card = Color(0xFF102430)
private val Accent = Color(0xFF20E59A)
private val Secondary = Color(0xFF8FA5B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GondolaIAApp() }
    }
}

@Composable
fun GondolaIAApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = Card,
            primary = Accent
        )
    ) {
        var message by remember { mutableStateOf("") }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Background)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(34.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        modifier = Modifier.size(82.dp),
                        shape = RoundedCornerShape(24.dp),
                        color = Card
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Psychology,
                                contentDescription = null,
                                tint = Accent,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    Text(
                        "Góndola IA",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "La inteligencia artificial que te ayuda a organizar mejor tus góndolas",
                        modifier = Modifier.padding(top = 8.dp),
                        color = Secondary,
                        textAlign = TextAlign.Center,
                        fontSize = 15.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Feature(Icons.Default.CameraAlt, "Analiza
a góndola")
                Feature(Icons.Default.Psychology, "Detecta
productos")
                Feature(Icons.Default.Palette, "Sugiere la
mejor distribución")
            }

            Spacer(Modifier.height(26.dp))

            Text(
                "Más orden = Más ventas",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = Accent,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(22.dp))

            Button(
                onClick = { message = "Próximo paso: abrir cámara y analizar la góndola." },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = Color(0xFF03120D)
                )
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text("Escanear góndola", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }

            if (message.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(message, color = Secondary, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.weight(1f))

            NavigationBar(
                containerColor = Color(0xFF081923),
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = {},
                    icon = { Icon(Icons.Default.CameraAlt, null) },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = {},
                    icon = { Icon(Icons.Default.History, null) },
                    label = { Text("Historial") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = {},
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("Ajustes") }
                )
            }
        }
    }
}

@Composable
private fun Feature(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(105.dp)
    ) {
        Surface(
            modifier = Modifier.size(52.dp),
            shape = RoundedCornerShape(15.dp),
            color = Card
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text,
            color = Color.White,
            textAlign = TextAlign.Center,
            fontSize = 12.sp,
            lineHeight = 15.sp
        )
    }
}
